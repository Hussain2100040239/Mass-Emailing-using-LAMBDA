## Resources to refer to:
1. https://uwm-cloudblog.net/topics/serverless-computing/serverless-mass-emailing-with-aws-lambda/
2. https://www.linkedin.com/pulse/mass-emailing-using-aws-lambda-ses-keerthana-mandadi/
3. https://repost.aws/knowledge-center/lambda-send-email-ses
4. https://www.jobsity.com/blog/tutorial-send-emails-using-aws-ses-lambda-functions
5. https://www.prplbx.com/resources/blog/transactional-emails-using-lambda-and-amazon-ses/
