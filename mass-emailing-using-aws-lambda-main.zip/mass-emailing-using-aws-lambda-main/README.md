# mass-emailing-using-aws-lambda

## Overview
In today’s busy world, sending bulk emails every day to thousands of users is becoming a challenge, so to make it easy for the users, AWS provides many services. One of the services is a simple email service that integrates into any application for bulk email sending, and you pay only for what you use.

## Architecture Diagram
![image](https://github.com/AWS-Serverless-Squad/mass-emailing-using-aws-lambda/assets/133768988/75e7a828-bbbb-488c-900d-071d99d6eca5)
